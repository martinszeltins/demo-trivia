export default {
    namespaced: true,

    state()
    {
        return {
            theme: 'dark',
            app_name: 'scaffold_app_name',
        }
    },

    actions: 
    {
        
    },

    mutations:
    {
        
    },
}