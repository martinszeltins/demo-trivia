<template>
    <div>
        <b>Login layout</b> <br><br>

        <div>
            <router-view></router-view>
        </div>
    </div>
</template>