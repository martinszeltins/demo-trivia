module.exports = {
    optimizeDeps: {
        include: ['date-fns/locale/eo', 'date-fns/fp'],
    },
    hmr: {
        port: 15319
    }
}