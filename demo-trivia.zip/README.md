# Demo trivia

**Instructions**

````
$ INSTALL DOCKER
$ git clone https://github.com/martinszeltins/demo-trivia.git
$ cd demo-trivia
$ docker-compose up -d
````

*Give it a few minutes to build.*
*And another minute after the build to install dependencies.*

The app will be running at [http://localhost:15319/](http://localhost:15319/)